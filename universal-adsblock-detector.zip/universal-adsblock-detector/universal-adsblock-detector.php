<?php
/*
Plugin Name: Universal AdsBlock Detector
Plugin URI: https://github.com/ilblogdicristiangallo/Universal-Adsblock-Detector
Description: Rileva AdBlock e VPN con DNS filtranti e mostra un messaggio bloccante. Compatibile con tutti i temi e dispositivi.
Version: 1.2
Author: Cristian Gallo
Author URI: https://www.ilblogdicristiangallo.com
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/

defined('ABSPATH') or exit;

// Includi moduli
require_once plugin_dir_path(__FILE__) . 'inc/detector-core.php';
if (is_admin()) {
    require_once plugin_dir_path(__FILE__) . 'admin/settings.php';
}

// Carica risorse frontend
function uadbd_enqueue_assets() {
    wp_enqueue_style('uadbd-style', plugin_dir_url(__FILE__) . 'assets/css/style.css');
    wp_enqueue_script('uadbd-script', plugin_dir_url(__FILE__) . 'assets/js/detector.js', array(), null, true);
}
add_action('wp_enqueue_scripts', 'uadbd_enqueue_assets');

// Carica risorse admin
function uadbd_enqueue_admin_assets() {
    wp_enqueue_style('uadbd-admin-style', plugin_dir_url(__FILE__) . 'admin/admin.css');
    wp_enqueue_script('uadbd-admin-script', plugin_dir_url(__FILE__) . 'admin/admin.js', array(), null, true);
}
add_action('admin_enqueue_scripts', 'uadbd_enqueue_admin_assets');

// Inserisce il popup nel footer solo se non è una richiesta AI/headless o login
function uadbd_render_popup() {
    if (!uadbd_is_bot_request()) {
        include plugin_dir_path(__FILE__) . 'templates/popup.php';
    }
}

function uadbd_is_bot_request() {
    // Escludi pagina di login
    if (isset($_SERVER['REQUEST_URI']) && strpos($_SERVER['REQUEST_URI'], 'wp-login.php') !== false) {
        return true;
    }

    // Escludi se mancano informazioni sul browser
    if (!isset($_SERVER['HTTP_USER_AGENT'])) {
        return true;
    }

    $ua = $_SERVER['HTTP_USER_AGENT'];
    return preg_match('/(bot|crawler|spider|headless|Copilot|AI)/i', $ua);
}

add_action('wp_footer', 'uadbd_render_popup');

