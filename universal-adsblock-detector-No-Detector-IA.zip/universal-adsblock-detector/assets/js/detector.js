document.addEventListener("DOMContentLoaded", function () {

    // ---------- INIZIO PATCH TRUSTED REQUEST ----------
    if (window.UADBD_TRUSTED) {
        const popup = document.getElementById('uadbd-popup');
        if (popup) popup.style.display = 'none';
        return;
    }
    // ---------- FINE PATCH TRUSTED REQUEST ----------

    const popup = document.getElementById('uadbd-popup');

    function showPopup() {
        if (popup) popup.style.display = 'block';
    }

    function hidePopup() {
        if (popup) popup.style.display = 'none';
    }

    function detectAdBlock(callback) {
        const bait = document.createElement('div');
        bait.className = 'adsbox';
        bait.style.position = 'absolute';
        bait.style.height = '1px';
        bait.style.width = '1px';
        bait.style.top = '-1000px';
        bait.style.left = '-1000px';
        bait.style.zIndex = '-1';
        bait.style.background = 'url(/ads.jpg)';
        document.body.appendChild(bait);

        setTimeout(function () {
            const blocked = window.getComputedStyle(bait).display === 'none' || bait.offsetHeight === 0;
            bait.remove();
            callback(blocked);
        }, 100);
    }

    function detectAdsbyGoogle(callback) {
        const script = document.createElement('script');
        script.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js";
        script.async = true;
        script.onerror = () => callback(true);
        script.onload = () => callback(false);
        document.head.appendChild(script);
    }

    function detectVPN(callback) {
        fetch("https://ipinfo.io/json")
            .then(res => res.json())
            .then(data => {
                const vpnASNs = [
                    "AS212238","AS40027","AS200052","AS54600","AS396507","AS51852",
                    "AS396982","AS20473","AS60404","AS197595","AS29748","AS13335",
                    "AS32097","AS53667","AS20278","AS12876","AS9009","AS132203"
                ];
                const isVPN = data.org && vpnASNs.some(asn => data.org.includes(asn));
                callback(isVPN);
            })
            .catch(() => callback(false));
    }

    function checkAll(callback) {
        detectAdBlock(function (adblockDetected) {
            if (adblockDetected) return callback(true);
            detectAdsbyGoogle(function (adsBlocked) {
                if (adsBlocked) return callback(true);
                detectVPN(function (vpnDetected) {
                    callback(vpnDetected);
                });
            });
        });
    }

    checkAll(function (blocked) {
        if (blocked) showPopup();
        else hidePopup();
    });

    const refreshBtn = popup ? popup.querySelector('button') : null;
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function (e) {
            e.preventDefault();
            checkAll(function (blocked) {
                if (blocked) {
                    alert("AdBlock o VPN ancora attivi.");
                } else {
                    hidePopup();
                    location.reload();
                }
            });
        });
    }
});



