<?php
// Protezione diretta
if (!defined('ABSPATH')) exit;

// Aggiunge voce nel menu Impostazioni
function uadbd_add_admin_menu() {
    add_options_page(
        'Universal AdsBlock Detector',
        'AdsBlock Detector',
        'manage_options',
        'uadbd-settings',
        'uadbd_render_settings_page'
    );
}
add_action('admin_menu', 'uadbd_add_admin_menu');

// Registra impostazioni
function uadbd_register_settings() {
    register_setting('uadbd_settings_group', 'uadbd_popup_message');
    register_setting('uadbd_settings_group', 'uadbd_enable_vpn_detection');
}
add_action('admin_init', 'uadbd_register_settings');

// Renderizza pagina impostazioni
function uadbd_render_settings_page() {
    ?>
    <div class="wrap">
        <h1>Universal AdsBlock Detector</h1>
        <form method="post" action="options.php">
            <?php settings_fields('uadbd_settings_group'); ?>
            <?php do_settings_sections('uadbd_settings_group'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Messaggio popup</th>
                    <td>
                        <textarea name="uadbd_popup_message" rows="5" cols="50"><?php echo esc_textarea(get_option('uadbd_popup_message', 'Abbiamo rilevato un blocco pubblicitario o una VPN con filtro DNS. Per favore, disattiva temporaneamente per supportare il nostro lavoro.')); ?></textarea>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Rilevamento VPN</th>
                    <td>
                        <input type="checkbox" name="uadbd_enable_vpn_detection" value="1" <?php checked(1, get_option('uadbd_enable_vpn_detection', 1)); ?> />
                        <label for="uadbd_enable_vpn_detection">Attiva rilevamento VPN via ASN</label>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

