<?php defined('ABSPATH') or exit;

// 🔐 Verifica se un ASN è noto per VPN
function uadbd_is_vpn_asn($asn) {
    $vpn_asns = array(
        'AS212238','AS40027','AS200052','AS54600','AS396507','AS51852',
        'AS396982','AS20473','AS60404','AS197595','AS29748','AS13335',
        'AS32097','AS53667','AS20278','AS12876','AS9009','AS132203'
    );
    return in_array($asn, $vpn_asns);
}

// 🔐 Verifica se la richiesta è trusted (firma HMAC valida)
function uadbd_is_trusted_request() {
    if (!defined('UADBD_TRUSTED_SECRET') || empty(UADBD_TRUSTED_SECRET)) {
        return false;
    }

    $sig = $_SERVER['HTTP_X_UADBD_SIGNATURE'] ?? '';
    $ts  = isset($_SERVER['HTTP_X_UADBD_TIMESTAMP']) ? intval($_SERVER['HTTP_X_UADBD_TIMESTAMP']) : 0;

    if (!$sig || !$ts || abs(time() - $ts) > 120) {
        return false;
    }

    $uri = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
    $payload = $uri . '|' . $ts;
    $expected = hash_hmac('sha256', $payload, UADBD_TRUSTED_SECRET);

    return hash_equals($expected, $sig);
}

// 🧠 Inietta il flag JS solo se la richiesta è trusted
add_action('wp_head', function() {
    if (uadbd_is_trusted_request()) {
        echo "<script>window.UADBD_TRUSTED=true;</script>";
    }
});






