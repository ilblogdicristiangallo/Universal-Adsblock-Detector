<?php defined('ABSPATH') or exit;

// Modulo core per estensioni future (admin panel, log ASN, ecc.)

function uadbd_is_vpn_asn($asn) {
    $vpn_asns = array(
        'AS212238', // NordVPN - Threat Protection / CyberSec
        'AS40027',  // Surfshark - CleanWeb
        'AS200052', // ProtonVPN - NetShield
        'AS54600',  // Private Internet Access - MACE
        'AS396507', // Windscribe - R.O.B.E.R.T.
        'AS51852',  // CyberGhost - AdBlock + Malware Blocker
        'AS396982', // Atlas VPN - SafeBrowse
        'AS20473',  // AdGuard VPN - AdGuard DNS integrato
        'AS60404',  // Hide.me - Tracker Blocker
        'AS197595', // Mullvad VPN - DNS personalizzato con blocco pubblicità
        'AS29748',  // PureVPN - DNS configurabile, blocco pubblicità via app
        'AS13335',  // Cloudflare WARP - DNS filtrante (parziale blocco tracker)
        'AS32097',  // IVPN - DNS personalizzato con blocco tracker
        'AS53667',  // TunnelBear - GhostBear + blocco tracker
        'AS20278',  // StrongVPN - DNS configurabile, blocco malware
        'AS12876',  // Hotspot Shield - blocco pubblicità via app
        'AS9009',   // VyprVPN - NAT firewall + DNS filtrante
        'AS132203'  // ZoogVPN - DNS con blocco malware e tracker
    );
    return in_array($asn, $vpn_asns);
}
