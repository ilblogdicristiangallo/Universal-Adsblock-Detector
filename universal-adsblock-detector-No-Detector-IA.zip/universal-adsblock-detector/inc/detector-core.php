<?php defined('ABSPATH') or exit;

// Modulo core per estensioni future (admin panel, log ASN, ecc.)
function uadbd_is_vpn_asn($asn) {
    $vpn_asns = array(
        'AS212238','AS40027','AS200052','AS54600','AS396507','AS51852',
        'AS396982','AS20473','AS60404','AS197595','AS29748','AS13335',
        'AS32097','AS53667','AS20278','AS12876','AS9009','AS132203'
    );
    return in_array($asn, $vpn_asns);
}

// ---------- INIZIO PATCH TRUSTED REQUEST ----------
function uadbd_is_trusted_request() {
    if (!defined('UADBD_TRUSTED_SECRET') || empty(UADBD_TRUSTED_SECRET)) return false;

    $sig = isset($_SERVER['HTTP_X_UADBD_SIGNATURE']) ? $_SERVER['HTTP_X_UADBD_SIGNATURE'] : '';
    $ts  = isset($_SERVER['HTTP_X_UADBD_TIMESTAMP']) ? intval($_SERVER['HTTP_X_UADBD_TIMESTAMP']) : 0;

    if (!$sig || !$ts || abs(time() - $ts) > 120) return false;

    $payload = $_SERVER['REQUEST_URI'] . '|' . $ts;
    $expected = hash_hmac('sha256', $payload, UADBD_TRUSTED_SECRET);

    return hash_equals($expected, $sig);
}

if (uadbd_is_trusted_request()) {
    add_action('wp_head', function() {
        echo "<script>window.UADBD_TRUSTED=true;</script>";
    });
}
// ---------- FINE PATCH TRUSTED REQUEST ----------


