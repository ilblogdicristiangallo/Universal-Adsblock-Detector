<?php
/*
Plugin Name: Universal AdsBlock Detector
Plugin URI: https://yourdomain.com/universal-adsblock-detector
Description: Rileva AdBlock e VPN con DNS filtranti e mostra un messaggio bloccante. Compatibile con tutti i temi e dispositivi.
Version: 1.0
Author: Cristian Gallo
Author URI: https://www.ilblogdicristiangallo.com
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/

defined('ABSPATH') or exit;

// Includi moduli
require_once plugin_dir_path(__FILE__) . 'inc/detector-core.php';
if (is_admin()) {
    require_once plugin_dir_path(__FILE__) . 'admin/settings.php';
}

// Carica risorse frontend
function uadbd_enqueue_assets() {
    wp_enqueue_style('uadbd-style', plugin_dir_url(__FILE__) . 'assets/css/style.css');
    wp_enqueue_script('uadbd-script', plugin_dir_url(__FILE__) . 'assets/js/detector.js', array(), null, true);
}
add_action('wp_enqueue_scripts', 'uadbd_enqueue_assets');

// Carica risorse admin
function uadbd_enqueue_admin_assets() {
    wp_enqueue_style('uadbd-admin-style', plugin_dir_url(__FILE__) . 'admin/admin.css');
    wp_enqueue_script('uadbd-admin-script', plugin_dir_url(__FILE__) . 'admin/admin.js', array(), null, true);
}
add_action('admin_enqueue_scripts', 'uadbd_enqueue_admin_assets');

// Inserisce il popup nel footer
function uadbd_render_popup() {
    include plugin_dir_path(__FILE__) . 'templates/popup.php';
}
add_action('wp_footer', 'uadbd_render_popup');
