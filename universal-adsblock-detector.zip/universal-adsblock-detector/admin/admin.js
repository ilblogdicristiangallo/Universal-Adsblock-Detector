document.addEventListener("DOMContentLoaded", function () {
    const textarea = document.querySelector('textarea[name="uadbd_popup_message"]');
    if (textarea) {
        textarea.addEventListener("input", function () {
            if (this.value.length > 500) {
                alert("Il messaggio è troppo lungo. Limite consigliato: 500 caratteri.");
            }
        });
    }
});

