<?php
defined('ABSPATH') or exit;

$popup_message = get_option(
    'uadbd_popup_message',
    'Abbiamo rilevato un blocco pubblicitario o una VPN con filtro DNS. Per favore, disattiva temporaneamente per supportare il nostro lavoro. We detected an ad blocker or a VPN with DNS filtering. Kindly disable it temporarily to support our work.'
);
?>

<div id="uadbd-popup" class="uadbd-popup" style="display:none;">
  <div class="uadbd-popup-inner">
    <div class="uadbd-icon">
      <img src="<?php echo esc_url(plugin_dir_url(__FILE__) . '../assets/img/adblock-icon.png'); ?>" alt="AdBlock rilevato" />
    </div>
    <div class="uadbd-message">
      <p><?php echo esc_html($popup_message); ?></p>
      <button onclick="location.reload();">Ricarica / Refresh</button>
    </div>
  </div>
</div>

<script>
(function(){
  // Se ambiente AI/headless ha impostato il flag, non mostrare nulla
  if (window.UADBD_TRUSTED === true) return;

  // Rilevamento AdBlock via bait
  var bait = document.createElement('div');
  bait.className = 'adsbox';
  bait.style.height = '1px';
  bait.style.width = '1px';
  bait.style.position = 'absolute';
  bait.style.left = '-999px';
  document.body.appendChild(bait);

  setTimeout(function(){
    if (!bait || bait.offsetHeight === 0) {
      var popup = document.getElementById('uadbd-popup');
      if (popup) popup.style.display = 'block';
    }
    bait.remove();
  }, 500);
})();
</script>
